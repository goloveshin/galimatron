//
// Created by Matthew Patterson on 23/01/2025.
//

#include "saxonc/saxonc_version.h"

char*    get_saxonc_version() {
    return "13.0.0";
}
unsigned get_saxonc_version_major() {
    return 13 +0;
}
unsigned get_saxonc_version_minor() {
    return  +0;
}
unsigned get_saxonc_version_patch() {
    return  +0;
}
unsigned get_saxonc_version_tweak() {
    return  +0;
}
