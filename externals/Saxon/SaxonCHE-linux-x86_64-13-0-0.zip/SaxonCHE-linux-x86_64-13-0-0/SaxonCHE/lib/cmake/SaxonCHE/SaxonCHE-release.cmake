#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SaxonCHE::saxonc-he" for configuration "Release"
set_property(TARGET SaxonCHE::saxonc-he APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SaxonCHE::saxonc-he PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsaxonc-he.so.13.0.0"
  IMPORTED_SONAME_RELEASE "libsaxonc-he.so.13"
  )

list(APPEND _cmake_import_check_targets SaxonCHE::saxonc-he )
list(APPEND _cmake_import_check_files_for_SaxonCHE::saxonc-he "${_IMPORT_PREFIX}/lib/libsaxonc-he.so.13.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
