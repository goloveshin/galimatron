#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "SaxonCCoreHE::saxonc-core-he" for configuration "Release"
set_property(TARGET SaxonCCoreHE::saxonc-core-he APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(SaxonCCoreHE::saxonc-core-he PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libsaxonc-core-he.so.13.0.0"
  IMPORTED_SONAME_RELEASE "libsaxonc-core-he.so.13"
  )

list(APPEND _cmake_import_check_targets SaxonCCoreHE::saxonc-core-he )
list(APPEND _cmake_import_check_files_for_SaxonCCoreHE::saxonc-core-he "${_IMPORT_PREFIX}/lib/libsaxonc-core-he.so.13.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
